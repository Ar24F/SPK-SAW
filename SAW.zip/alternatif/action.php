<?php
	// ambil data alternatif dari table alternatif
	function ambil_data() {
	    global $koneksi;
	    $query = "SELECT * FROM alternatif ORDER BY CAST(SUBSTRING(id_alternatif, 3) AS UNSIGNED)";
	    $result = $koneksi->query($query);

	    $data = array();

	    while ($row = $result->fetch_assoc()) {
	        $data[] = $row;
	    }

	    return $data;
	}


	// generate kode otomatis untuk id alternatif
	function kode_otomatis() {
	    global $koneksi;
	    $query = "SELECT MAX(CAST(SUBSTRING(id_alternatif, 3) AS UNSIGNED)) as max_id FROM alternatif";
	    $result = $koneksi->query($query);
	    $row = $result->fetch_assoc();
	    $maxID = $row["max_id"];

	    $urutan = $maxID;
	    $urutan++;

	    $maxID = 'AL' . sprintf("%01s", $urutan);

	    return $maxID;
	}


	// tambah data alternatif
	function tambah_data($id, $value1) {
	    global $koneksi;
	    $stmt = $koneksi->prepare("INSERT INTO alternatif (id_alternatif, nama_alternatif) VALUES (?, ?)");
	    $stmt->bind_param("ss", $id, $value1);
	    return $stmt->execute();
	}


	// ambil data alternatif berdasarkan id
	function ambil_data_by_id($id) {
	    global $koneksi;
	    $query = "SELECT * FROM alternatif WHERE id_alternatif = ?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    $stmt->execute();
	    $result = $stmt->get_result();

	    if ($result->num_rows > 0) {
	        return $result->fetch_assoc();
	    }
	}


	// ubah data alternatif
	function ubah_data($id, $value1) {
	    global $koneksi;
	    $query = "UPDATE alternatif SET nama_alternatif=? WHERE id_alternatif=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("ss", $value1, $id);
	    return $stmt->execute();
	}


	// hapus data alternatif
	function hapus_data($id) {
	    global $koneksi;
	    $query = "DELETE FROM alternatif WHERE id_alternatif=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    return $stmt->execute();
	}


	// lainnya
		// ambil data kriteria dari table kriteria
		function ambil_data_kriteria() {
		    global $koneksi;
		    $query = "SELECT * FROM kriteria ORDER BY CAST(SUBSTRING(id_kriteria, 2) AS UNSIGNED)";
		    $result = $koneksi->query($query);

		    $data = array();

		    while ($row = $result->fetch_assoc()) {
		        $data[] = $row;
		    }

		    return $data;
		}

		// ambil data sub kriteria dari table sub kriteria
		function ambil_data_sub_kriteria_by_id_kriteria($id) {
		    global $koneksi;
		    $query = "SELECT * FROM subkriteria WHERE id_kriteria = ? ORDER BY nilai asc";
		    $stmt = $koneksi->prepare($query);
		    $stmt->bind_param("s", $id);
		    $stmt->execute();
		    $result = $stmt->get_result();

		    $data = array();

		    while ($row = $result->fetch_assoc()) {
		        $data[] = $row;
		    }

		    return $data;
		}

		// tambah data alternatif yang akan diproses ke table hasil
		function tambah_data_hasil($id, $value1, $value2) {
		    global $koneksi;
		    $stmt = $koneksi->prepare("INSERT INTO hasil (id_alternatif, nama_alternatif, hasil) VALUES (?, ?, ?)");
		    $stmt->bind_param("sss", $id, $value1, $value2);
		    return $stmt->execute();
		}

		// ubah data alternatif yang ada pada tabel hasil
		function ubah_data_hasil($id, $value1, $value2) {
		    global $koneksi;
		    $query = "UPDATE hasil SET nama_alternatif=?, hasil=? WHERE id_alternatif=?";
		    $stmt = $koneksi->prepare($query);
		    $stmt->bind_param("sss", $value1, $value2, $id);
		    return $stmt->execute();
		}

		// hapus data alternatif yang ada pada tabel hasil
		function hapus_data_hasil($id) {
		    global $koneksi;
		    $query = "DELETE FROM hasil WHERE id_alternatif=?";
		    $stmt = $koneksi->prepare($query);
		    $stmt->bind_param("s", $id);
		    return $stmt->execute();
		}


	// core (function dieksekusi ketika ada requset)
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		global $koneksi;
		// jika tombol tambah ditekan
		if (isset($_POST['tambah'])) {
			$id_alternatif = mysqli_real_escape_string($koneksi, $_POST["id_alternatif"]);
	        $nama_alternatif = mysqli_real_escape_string($koneksi, $_POST["nama_alternatif"]);

	        if (tambah_data($id_alternatif, $nama_alternatif)) {
	        	$data = ambil_data_kriteria();
	        	tambah_data_hasil($id_alternatif, $nama_alternatif, '');
	        	if ($data) {
	        		foreach ($data as $row) {
	        			$isirow = $row['id_kriteria'];
	                    $nilai_kriteria = mysqli_real_escape_string($koneksi, $_POST[$isirow]);
	                    $query = "UPDATE alternatif SET $isirow=? WHERE id_alternatif=?";
	                    $stmt = $koneksi->prepare($query);
	                    $stmt->bind_param("ss", $nilai_kriteria, $id_alternatif);
	                    $stmt->execute();
	        		}
	        	}
	        	$_SESSION['pesan'] = 'Data berhasil ditambah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal menambah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Data Alternatif');
		}


		// jika tombol ubah ditekan
		if (isset($_POST['ubah'])) {
			$id_alternatif = mysqli_real_escape_string($koneksi, $_POST["id_alternatif"]);
	        $nama_alternatif = mysqli_real_escape_string($koneksi, $_POST["nama_alternatif"]);

	        if (ubah_data($id_alternatif, $nama_alternatif)) {
	        	$data = ambil_data_kriteria();
	        	ubah_data_hasil($id_alternatif, $nama_alternatif, '');
	        	if ($data) {
	        		foreach ($data as $row) {
	        			$isirow = $row['id_kriteria'];
	                    $nilai_kriteria = mysqli_real_escape_string($koneksi, $_POST[$isirow]);
	                    $query = "UPDATE alternatif SET $isirow=? WHERE id_alternatif=?";
	                    $stmt = $koneksi->prepare($query);
	                    $stmt->bind_param("ss", $nilai_kriteria, $id_alternatif);
	                    $stmt->execute();
	        		}
	        	}
	        	$_SESSION['pesan'] = 'Data berhasil diubah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal mengubah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Data Alternatif');
		}


		// jika tombol hapus ditekan
		if (isset($_POST['hapus'])) {
			$id_alternatif = mysqli_real_escape_string($koneksi, $_POST["id_alternatif"]);

			if (hapus_data($id_alternatif)) {
				hapus_data_hasil($id_alternatif);
				$_SESSION['pesan'] = 'Data berhasil dihapus!';
				$_SESSION['status'] = 'success';
			} else {
				$_SESSION['pesan'] = 'Gagal menghapus data!';
				$_SESSION['status'] = 'danger';
			} header('Location: data.php?page=Data Alternatif');
		}
	}
?>
<?php $maxID = kode_otomatis(); ?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Alternatif:</label>
		<input type="text" class="form-control" name="id_alternatif" value="<?= $maxID; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nama Alternatif:</label>
		<input type="text" class="form-control" name="nama_alternatif" placeholder="Nama Alternatif" required>
	</div>
	
	<?php
		$data1 = ambil_data_kriteria();
		if ($data1) {
			foreach ($data1 as $row1) {
				$data2 = ambil_data_sub_kriteria_by_id_kriteria($row1['id_kriteria']);
				if ($data2) { ?>
					<div class="form-group mt-3">
						<label class="mb-1"><?= $row1['id_kriteria']; ?> (<?= $row1['nama_kriteria']; ?>):</label>
						<select class="form-control" name="<?= $row1['id_kriteria']; ?>" required>
							<option value="" disabled selected>Pilih Nilai kriteria yang sesuai...</option>
							<?php foreach ($data2 as $row2) { ?>
								<option><?= $row2['sub_kriteria']; ?></option>
							<?php } ?>
						</select>
					</div>
				<?php } else { ?>
					<div class="form-group mt-3">
						<label class="mb-1"><?= $row1['id_kriteria']; ?> (<?= $row1['nama_kriteria']; ?>):</label>
						<input type="text" class="form-control" name="<?= $row1['id_kriteria']; ?>" placeholder="Isi Nilai kriteria yang sesuai" required>
					</div>
	<?php } } } ?>
				
	<button type="submit" class="btn btn-ar24f mt-3" name="tambah">Tambah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Data Alternatif">kembali</a>
</form>
<?php
	$getid = $_GET['id'];
	$data1 = ambil_data_by_id($getid);
?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Alternatif:</label>
		<input type="text" class="form-control" name="id_alternatif" value="<?= $data1['id_alternatif']; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nama Alternatif:</label>
		<input type="text" class="form-control filled" name="nama_alternatif" value="<?= $data1['nama_alternatif']; ?>" required>
	</div>

	<?php
		$data2 = ambil_data_kriteria();
		if ($data2) {
			foreach ($data2 as $row1) {
				$data3 = ambil_data_sub_kriteria_by_id_kriteria($row1['id_kriteria']);
				if ($data3) { ?>
					<div class="form-group mt-3">
						<label class="mb-1"><?= $row1['id_kriteria']; ?> (<?= $row1['nama_kriteria']; ?>):</label>
						<select class="form-control" name="<?= $row1['id_kriteria']; ?>" required>
							<option value="<?= $data1[$row1['id_kriteria']]; ?>" selected><?= $data1[$row1['id_kriteria']]; ?></option>
							<?php foreach ($data3 as $row2) { ?>
								<option><?= $row2['sub_kriteria']; ?></option>
							<?php } ?>
						</select>
					</div>
				<?php } else { ?>
					<div class="form-group mt-3">
						<label class="mb-1"><?= $row1['id_kriteria']; ?> (<?= $row1['nama_kriteria']; ?>):</label>
						<input type="text" class="form-control filled" name="<?= $row1['id_kriteria']; ?>" value="<?= $data1[$row1['id_kriteria']]; ?>" required>
					</div>
	<?php } } } ?>
	<button type="submit" class="btn btn-ar24f mt-3" name="ubah">Ubah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Data Alternatif">kembali</a>
</form>

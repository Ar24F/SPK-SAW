<div class="table-responsive">
	<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th scope="col" class="nomor">No</th>
				<th scope="col">ID Alternatif</th>
				<th scope="col">Nama Alternatif</th>
				<?php
					$data1 = ambil_data_kriteria();
					$nomor1 = 1;
					if ($data1) {
						foreach ($data1 as $row1) { ?>
							<th scope="col"><?= $row1['id_kriteria']; ?></th>
				<?php $nomor1++; } } ?>
				<th scope="col" class="aksi">Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$data2 = ambil_data();
				$nomor2 = 1;
				if (empty($data2)) { ?>
					<tr><td colspan="<?= $nomor1 + 4; ?>" class="text-center">Data Alternatif Kosong</td></tr>
			<?php } else { foreach ($data2 as $row2) { ?>
					<tr>
						<th scope="row" class="nomor"><?= $nomor2; ?></th>
						<td><?= $row2['id_alternatif']; ?></td>
						<td><?= $row2['nama_alternatif']; ?></td>
						<?php
							if ($data1) {
								foreach ($data1 as $row3) { ?>
									<td><?= $row2[$row3['id_kriteria']]; ?></td>
						<?php } } ?>
						<th class="aksi">
							<form method="post">
								<input type="hidden" name="id_alternatif" value="<?= $row2['id_alternatif']; ?>">
								<a href="data.php?page=Ubah Alternatif&id=<?= $row2['id_alternatif']; ?>" class="badge rounded-pill text-bg-success">ubah</a>
								<button class="badge rounded-pill text-bg-danger" type="submit" name="hapus" onclick="return confirm('Anda yakin ingin menghapus data ini?')">hapus</button>
							</form>
						</th>
					</tr>
			<?php $nomor2++; } } ?>
		</tbody>
	</table>
</div>
<a class="btn btn-ar24f" href="data.php?page=Tambah Alternatif">Tambah Alternatif</a>
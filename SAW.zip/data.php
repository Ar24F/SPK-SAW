<?php
	session_start();

	// periksa apakah user sudah login
	if (!isset($_SESSION["username"])) {
		header("Location: index.php");
		exit;
	}

	// ambil id page yang di request
	$page = $_GET['page'];


	// menu
    $menuKriteria = array('Data Kriteria','Ubah Kriteria','Tambah Kriteria', 'Sub Kriteria','Ubah Sub Kriteria','Tambah Sub Kriteria');
    $menuAlternatif = array('Data Alternatif','Ubah Alternatif','Tambah Alternatif');


    // memanggil menu yang dipilih
    function request_page($pages) {
        if ($pages == 'Data Kriteria') {
            include 'kriteria/action.php';
            include 'kriteria/kriteria.php';
        } elseif ($pages == 'Ubah Kriteria') {
            include 'kriteria/action.php';
            include 'kriteria/ubah.php';
        } elseif ($pages == 'Tambah Kriteria') {
            include 'kriteria/action.php';
            include 'kriteria/tambah.php';
        }

        if ($pages == 'Sub Kriteria') {
            include 'subkriteria/action.php';
            include 'subkriteria/subkriteria.php';
        } elseif ($pages == 'Ubah Sub Kriteria') {
            include 'subkriteria/action.php';
            include 'subkriteria/ubah.php';
        } elseif ($pages == 'Tambah Sub Kriteria') {
            include 'subkriteria/action.php';
            include 'subkriteria/tambah.php';
        }

        if ($pages == 'Data Alternatif') {
            include 'alternatif/action.php';
            include 'alternatif/alternatif.php';
        } elseif ($pages == 'Ubah Alternatif') {
            include 'alternatif/action.php';
            include 'alternatif/ubah.php';
        } elseif ($pages == 'Tambah Alternatif') {
            include 'alternatif/action.php';
            include 'alternatif/tambah.php';
        }
    }


    // memberikan class active pada menu yang sedang dipilih
    function class_active($pages) {
        global $page;
        if (in_array($page, $pages)) {
            echo 'active';
        }
    }

	include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Ar24F | <?= $page; ?></title>
	<meta name="description" content="Simple Additive Weighting Method (SAW Method)">
	<meta name="keywords" content="SAW, SPK, Ar24F">

	<!-- icon -->
	<link rel="icon" href="assets/images/ar24f.png" sizes="any">
	<link rel="apple-touch-icon" href="assets/images/ar24f.png">

	<!-- bootstrap css -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- font icon -->
	<link rel="stylesheet" href="assets/bootstrap-icons/bootstrap-icons.css">

	<!-- main css -->
	<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

	<header id="header" class="header d-flex align-items-center">
		<div class="container d-flex align-items-center justify-content-between">
			<a href="home.php" class="logo">A<span>r2</span>4F</a>
			<nav id="navbar" class="navbar">
				<ul>
					<li><a href="home.php">Home</a></li>
		          	<li class="dropdown"><a class="<?= class_active($menuKriteria); ?>" href="#"><span>Data Kriteria</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
			            <ul>
			              <li><a href="data.php?page=Data Kriteria">Kriteria</a></li>
			              <li><a href="data.php?page=Sub Kriteria">Sub Kriteria</a></li>
			            </ul>
		          	</li>
					<li><a class="<?= class_active($menuAlternatif); ?>" href="data.php?page=Data Alternatif">Data Alternatif</a></li>
					<li><a class="btn btn-contact" href="https://wa.me/qr/4JPBYRWHBO7BC1" target="_blank">Ingin Konsultasi?</a></li>
				</ul>
			</nav>
			<i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
			<i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
		</div>
	</header>

	<main id="main">
		<section id="process" class="process">
			<div class="container">
				<?php
					if (isset($_SESSION['pesan'])) {
						echo "<div id='alert' class='alert alert-{$_SESSION['status']}' role='alert'>{$_SESSION['pesan']}</div>";
						unset($_SESSION['pesan']);
						unset($_SESSION['status']);
					}
					request_page($page);
				?>
			</div>
		</section>
	</main>

	<footer id="footer" class="footer">
		<div class="container">
			<div class="footer-info">
				<h4>Simple Additive Weighting (SAW)</h4>
				<p>
					Simple Additive Weighting (SAW) merupakan sebuah algoritma yang dapat memprediksi sebuah keputusan yang akan diambil dengan menjumlahkan bobot sesuai dengan kriteria yang telah ditentukan dan juga membutuhkan proses normalisasi matriks keputusan (X) ke suatu skala yang dapat diperbandingkan dengan semua rating alternatif yang ada
					(<a href="https://www.unisbank.ac.id/ojs/index.php/fti1/article/view/364/241">Eniyati, 2011</a>).
				</p>
			</div>
		</div>
		<div class="container mt-5">
			<div class="copyright">
				&copy; Copyright <strong><span>Simple Additive Weighting (SAW)</span></strong>. All Rights Reserved
      		</div>
      		<div class="credits">
      			Made by <a href="#">Rizky Fadhillah</a>
      		</div>
    	</div>
	</footer>

	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<!-- main js -->
	<script src="assets/js/main.js"></script>
</body>
</html>
<?php
require('assets/fpdf/fpdf.php');
require('koneksi.php');

class PDF extends FPDF {
	function ambil_data_hasil() {
		global $koneksi;
        $query = "SELECT * FROM hasil ORDER BY hasil desc";
        $result = $koneksi->query($query);
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    }
	function Header() {
		$this->SetFont('Arial','B',15);
		$this->Cell(80);
		$this->Cell(30,10,'LAPORAN HASIL METODE SAW',0,0,'C');
		$this->Ln(15);
	}
	function Footer(){
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	}
	function FancyTable($header, $data){
		$this->SetFillColor(255,187,79);
		$this->SetTextColor(29,28,27);
		$this->SetDrawColor(29,28,27);
		$this->SetLineWidth(.3);
		$this->SetFont('','B');
		$w = array(30, 40, 70, 50);
		for($i=0;$i<count($header);$i++)
			$this->Cell($w[$i],9,$header[$i],1,0,'C',true);
		$this->Ln();
		$this->SetFillColor(223,223,224);
		$this->SetTextColor(0);
		$this->SetFont('');
		$nomor = 1;
		$fill = false;
		foreach ($data as $row) {
			$this->Cell($w[0],8,$nomor,1,0,'C',$fill);
			$this->Cell($w[1],8,$row['id_alternatif'],1,0,'C',$fill);
			$this->Cell($w[2],8,$row['nama_alternatif'],1,0,'L',$fill);
			$this->Cell($w[3],8,number_format($row['hasil'],5),1,0,'C',$fill);
			$this->Ln();
			$nomor++;
			$fill = !$fill;
		}
		$this->Cell(array_sum($w),0,'','T');
	}
}

$pdf = new PDF();
$header = array('Ranking', 'ID Alternatif', 'Nama Alternatif', 'Preferensi (Vi)');
$data = $pdf->ambil_data_hasil();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);
$pdf->FancyTable($header, $data);
$pdf->Output('I', 'laporan-saw.pdf');
?>

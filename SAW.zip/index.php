<?php
	session_start();
	
	include 'koneksi.php';
	include 'proses.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Ar24F | SAW Method</title>
	<meta name="description" content="Simple Additive Weighting Method (SAW Method)">
	<meta name="keywords" content="SAW, SPK, Ar24F">

	<!-- icon -->
	<link rel="icon" href="assets/images/ar24f.png" sizes="any">
	<link rel="apple-touch-icon" href="assets/images/ar24f.png">

	<!-- bootstrap css -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- font icon -->
	<link rel="stylesheet" href="assets/bootstrap-icons/bootstrap-icons.css">

	<!-- main css -->
	<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

	<!-- preloader Ar24F -->
	<div class="ar24f" id="ar24f">
		<label><span>A</span><span>r</span><span>2</span><span>4</span><span>F</span>
		</label>
		<label><span></span></label>
	</div>

	<section id="login" class="login">
		<div class="section-header">
			<img src="assets/images/ar24f-s.png">
		</div>
		<form method="post" role="form">
			<div class="form-group mt-3">
				<label class="mb-1">Username:</label>
				<input type="text" class="form-control" name="username" placeholder="Masukkan Username" required>
			</div>
			<div class="form-group mt-3">
				<label class="mb-1">Password:</label>
				<input type="password" class="form-control" name="password" placeholder="Masukkan Password" required>
			</div>
			<?= '<label class="error">'.$errorlogin.'</label>' ?>
			<button type="submit" class="btn btn-ar24f mt-3" name="login">Login</button>
		</form>
	</section>

	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<!-- main js -->
	<script src="assets/js/main.js"></script>
</body>
</html>
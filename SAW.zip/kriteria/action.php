<?php
	// ambil data kriteria dari table kriteria
	function ambil_data() {
	    global $koneksi;
	    $query = "SELECT * FROM kriteria ORDER BY CAST(SUBSTRING(id_kriteria, 2) AS UNSIGNED)";
	    $result = $koneksi->query($query);

	    $data = array();

	    while ($row = $result->fetch_assoc()) {
	        $data[] = $row;
	    }

	    return $data;
	}


	// generate kode otomatis untuk id kriteria
	function kode_otomatis() {
	    global $koneksi;
	    $query = "SELECT MAX(CAST(SUBSTRING(id_kriteria, 2) AS UNSIGNED)) as max_id FROM kriteria";
	    $result = $koneksi->query($query);
	    $row = $result->fetch_assoc();
	    $maxID = $row["max_id"];

	    $urutan = $maxID;
	    $urutan++;

	    $maxID = 'C' . sprintf("%01s", $urutan);

	    return $maxID;
	}


	// tambah data kriteria
	function tambah_data($id, $value1, $value2, $value3) {
	    global $koneksi;
	    $stmt = $koneksi->prepare("INSERT INTO kriteria (id_kriteria, nama_kriteria, bobot, cost_benefit) VALUES (?, ?, ?, ?)");
	    $stmt->bind_param("ssis", $id, $value1, $value2, $value3);
	    return $stmt->execute();
	}


	// ambil data kriteria berdasarkan id
	function ambil_data_by_id($id) {
	    global $koneksi;
	    $query = "SELECT * FROM kriteria WHERE id_kriteria = ?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    $stmt->execute();
	    $result = $stmt->get_result();

	    if ($result->num_rows > 0) {
	        return $result->fetch_assoc();
	    }
	}


	// ubah data kriteria
	function ubah_data($id, $value1, $value2, $value3) {
	    global $koneksi;
	    $query = "UPDATE kriteria SET nama_kriteria=?, bobot=?, cost_benefit=? WHERE id_kriteria=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("siss", $value1, $value2, $value3, $id);
	    return $stmt->execute();
	}


	// hapus data kriteria
	function hapus_data($id) {
	    global $koneksi;
	    $query = "DELETE FROM kriteria WHERE id_kriteria=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    return $stmt->execute();
	}


	// lainnya
		// tambah id kriteria ke kolom table alternatif
		function tambah_kolom_ke_table($id) {
		    global $koneksi;
		    $sql_add_column = "ALTER TABLE alternatif ADD COLUMN $id VARCHAR(50)";
		    $stmt = $koneksi->prepare($sql_add_column);
		    return $stmt->execute();
		}

		// hapus id kriteria dari kolom table alternatif
		function hapus_kolom_dari_table($id) {
		    global $koneksi;
		    $sql_drop_column = "ALTER TABLE alternatif DROP COLUMN $id";
		    $stmt = $koneksi->prepare($sql_drop_column);
		    return $stmt->execute();
		}

		// hapus data sub kriteria jika kriteria dihapus
		function hapus_sub_kriteria($id) {
		    global $koneksi;
		    $query = "DELETE FROM subkriteria WHERE id_kriteria=?";
		    $stmt = $koneksi->prepare($query);
		    $stmt->bind_param("s", $id);
		    return $stmt->execute();
		}


	// core (function dieksekusi ketika ada requset)
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		global $koneksi;
		// jika tombol tambah ditekan
		if (isset($_POST['tambah'])) {
			$id_kriteria = mysqli_real_escape_string($koneksi, $_POST["id_kriteria"]);
	        $nama_kriteria = mysqli_real_escape_string($koneksi, $_POST["nama_kriteria"]);
	        $bobot = mysqli_real_escape_string($koneksi, $_POST["bobot"]);
	        $cost_benefit = mysqli_real_escape_string($koneksi, $_POST["cost_benefit"]);

	        if (tambah_data($id_kriteria, $nama_kriteria, $bobot, $cost_benefit)) {
	        	tambah_kolom_ke_table($id_kriteria);
	        	$_SESSION['pesan'] = 'Data berhasil ditambah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal menambah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Data Kriteria');
		}


		// jika tombol ubah ditekan
		if (isset($_POST['ubah'])) {
			$id_kriteria = mysqli_real_escape_string($koneksi, $_POST["id_kriteria"]);
	        $nama_kriteria = mysqli_real_escape_string($koneksi, $_POST["nama_kriteria"]);
	        $bobot = mysqli_real_escape_string($koneksi, $_POST["bobot"]);
	        $cost_benefit = mysqli_real_escape_string($koneksi, $_POST["cost_benefit"]);

	        if (ubah_data($id_kriteria, $nama_kriteria, $bobot, $cost_benefit)) {
	        	$_SESSION['pesan'] = 'Data berhasil diubah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal mengubah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Data Kriteria');
		}


		// jika tombol hapus ditekan
		if (isset($_POST['hapus'])) {
			$id_kriteria = mysqli_real_escape_string($koneksi, $_POST["id_kriteria"]);

			if (hapus_data($id_kriteria)) {
				hapus_kolom_dari_table($id_kriteria);
				hapus_sub_kriteria($id_kriteria);
				$_SESSION['pesan'] = 'Data berhasil dihapus!';
				$_SESSION['status'] = 'success';
			} else {
				$_SESSION['pesan'] = 'Gagal menghapus data!';
				$_SESSION['status'] = 'danger';
			} header('Location: data.php?page=Data Kriteria');
		}
	}
?>
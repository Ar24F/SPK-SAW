<?php $maxID = kode_otomatis(); ?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Kriteria:</label>
		<input type="text" class="form-control" name="id_kriteria" value="<?= $maxID; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nama Kriteria:</label>
		<input type="text" class="form-control" name="nama_kriteria" placeholder="Nama Kriteria" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Bobot:</label>
		<input type="number" class="form-control" name="bobot" placeholder="Nilai Bobot Kriteria" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Cost/Benefit:</label>
		<select class="form-control" name="cost_benefit" required>
			<option value="" disabled selected>Kriteria termasuk Cost atau Benefit</option>
			<option>Cost</option>
			<option>Benefit</option>
		</select>
	</div>
	<button type="submit" class="btn btn-ar24f mt-3" name="tambah">Tambah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Data Kriteria">kembali</a>
</form>
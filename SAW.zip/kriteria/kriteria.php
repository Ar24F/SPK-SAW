<div class="table-responsive">
	<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th scope="col" class="nomor">No</th>
				<th scope="col">ID Kriteria</th>
				<th scope="col">Nama Kriteria</th>
				<th scope="col">Bobot</th>
				<th scope="col">Cost/Benefit</th>
				<th scope="col" class="aksi">Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$data = ambil_data();
				$nomor = 1;
				if (empty($data)) { ?>
					<tr><td colspan="6" class="text-center">Data Kriteria Kosong</td></tr>
			<?php } else { foreach ($data as $row) { ?>
					<tr>
						<th scope="row" class="nomor"><?= $nomor; ?></th>
						<td><?= $row['id_kriteria']; ?></td>
						<td><?= $row['nama_kriteria']; ?></td>
						<td><?= $row['bobot']; ?></td>
						<td><?= $row['cost_benefit']; ?></td>
						<th class="aksi">
							<form method="post">
								<input type="hidden" name="id_kriteria" value="<?= $row['id_kriteria']; ?>">
								<a href="data.php?page=Ubah Kriteria&id=<?= $row['id_kriteria']; ?>" class="badge rounded-pill text-bg-success">ubah</a>
								<button class="badge rounded-pill text-bg-danger" type="submit" name="hapus" onclick="return confirm('Anda yakin ingin menghapus data ini?')">hapus</button>
							</form>
						</th>
					</tr>
			<?php $nomor++; } } ?>
		</tbody>
	</table>
</div>
<a class="btn btn-ar24f" href="data.php?page=Tambah Kriteria">Tambah Kriteria</a>
<?php
	$getid = $_GET['id'];
	$data = ambil_data_by_id($getid);
?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Kriteria:</label>
		<input type="text" class="form-control" name="id_kriteria" value="<?= $data['id_kriteria']; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nama Kriteria:</label>
		<input type="text" class="form-control filled" name="nama_kriteria" value="<?= $data['nama_kriteria']; ?>" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Bobot:</label>
		<input type="number" class="form-control filled" name="bobot" value="<?= $data['bobot']; ?>" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Cost/Benefit:</label>
		<select class="form-control filled" name="cost_benefit" required>
			<option selected><?= $data['cost_benefit']; ?></option>
			<option>Cost</option>
			<option>Benefit</option>
		</select>
	</div>
	<button type="submit" class="btn btn-ar24f mt-3" name="ubah">Ubah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Data Kriteria">kembali</a>
</form>
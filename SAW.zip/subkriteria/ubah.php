<?php
	$getid = $_GET['id'];
	$data1 = ambil_data_by_id($getid);
?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Sub Kriteria:</label>
		<input type="text" class="form-control" name="id_subkriteria" value="<?= $data1['id_subkriteria']; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">ID Kriteria:</label>
		<select class="form-control filled" name="id_kriteria" required>
			<option value="<?= $data1['id_kriteria']; ?>" selected><?= $data1['id_kriteria']; ?></option>
			<?php
				$data2 = ambil_data_kriteria();
				foreach ($data2 as $row) { ?>
					<option value="<?= $row['id_kriteria']; ?>"><?= $row['id_kriteria']; ?> (<?= $row['nama_kriteria']; ?>)</option>
		    <?php } ?>
		</select>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Sub Kriteria:</label>
		<input type="text" class="form-control filled" name="sub_kriteria" value="<?= $data1['sub_kriteria']; ?>" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nilai:</label>
		<input type="number" class="form-control filled" name="nilai" value="<?= $data1['nilai']; ?>" required>
	</div>
	<button type="submit" class="btn btn-ar24f mt-3" name="ubah">Ubah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Sub Kriteria">kembali</a>
</form>
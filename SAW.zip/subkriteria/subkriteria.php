<?php
	$data1 = ambil_data_kriteria();
	$nomor1 = 1; 
	foreach ($data1 as $row1) {
?>
<h1 class="table-tittle">
	<strong><span><?= $nomor1; ?>.</span><?= $row1['nama_kriteria']; ?></strong>
</h1>
<div class="table-responsive">
	<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th scope="col" class="nomor">No</th>
				<th scope="col">Sub Kriteria</th>
				<th scope="col">Nilai</th>
				<th scope="col" class="aksi">Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$data2 = ambil_data_sub_kriteria_by_id_kriteria($row1['id_kriteria']);
				$nomor2 = 1;
				if (empty($data2)) { ?>
					<tr><td colspan="4" class="text-center">Tidak Memiliki Sub Kriteria</td></tr>
			<?php } else { foreach ($data2 as $row2) { ?>
					<tr>
						<th scope="row" class="nomor"><?= $nomor2; ?></th>
						<td><?= $row2['sub_kriteria']; ?></td>
						<td><?= $row2['nilai']; ?></td>
						<th class="aksi">
							<form method="post">
								<input type="hidden" name="id_subkriteria" value="<?= $row2['id_subkriteria']; ?>">
								<a href="data.php?page=Ubah Sub Kriteria&id=<?= $row2['id_subkriteria']; ?>" class="badge rounded-pill text-bg-success">ubah</a>
								<button class="badge rounded-pill text-bg-danger" type="submit" name="hapus" onclick="return confirm('Anda yakin ingin menghapus data ini?')">hapus</button>
							</form>
						</th>
					</tr>
			<?php $nomor2++; } } ?>
		</tbody>
	</table>
</div>
<?php $nomor1++; } ?>
<a class="btn btn-ar24f" href="data.php?page=Tambah Sub Kriteria">Tambah Sub Kriteria</a>
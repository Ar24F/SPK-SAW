<?php
	// ambil data sub kriteria dari table sub kriteria berdasarkan id
	function ambil_data_sub_kriteria_by_id_kriteria($id) {
	    global $koneksi;
	    $query = "SELECT * FROM subkriteria WHERE id_kriteria = ? ORDER BY nilai asc";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    $stmt->execute();
	    $result = $stmt->get_result();

	    $data = array();

	    while ($row = $result->fetch_assoc()) {
	        $data[] = $row;
	    }

	    return $data;
	}


	// generate kode otomatis untuk id sub kriteria
	function kode_otomatis() {
	    global $koneksi;
	    $query = "SELECT MAX(CAST(SUBSTRING(id_subkriteria, 3) AS UNSIGNED)) as max_id FROM subkriteria";
	    $result = $koneksi->query($query);
	    $row = $result->fetch_assoc();
	    $maxID = $row["max_id"];

	    $urutan = $maxID;
	    $urutan++;

	    $maxID = 'SC' . sprintf("%01s", $urutan);

	    return $maxID;
	}


	// tambah data sub kriteria
	function tambah_data($id, $value1, $value2, $value3) {
	    global $koneksi;
	    $stmt = $koneksi->prepare("INSERT INTO subkriteria (id_subkriteria, id_kriteria, sub_kriteria, nilai) VALUES (?, ?, ?, ?)");
	    $stmt->bind_param("sssi", $id, $value1, $value2, $value3);
	    return $stmt->execute();
	}


	// ambil data sub kriteria berdasarkan id
	function ambil_data_by_id($id) {
	    global $koneksi;
	    $query = "SELECT * FROM subkriteria WHERE id_subkriteria = ?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    $stmt->execute();
	    $result = $stmt->get_result();

	    if ($result->num_rows > 0) {
	        return $result->fetch_assoc();
	    }
	}


	// ubah data sub kriteria
	function ubah_data($id, $value1, $value2, $value3) {
	    global $koneksi;
	    $query = "UPDATE subkriteria SET id_kriteria=?, sub_kriteria=?, nilai=? WHERE id_subkriteria=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("ssis", $value1, $value2, $value3, $id);
	    return $stmt->execute();
	}


	// hapus data sub kriteria
	function hapus_data($id) {
	    global $koneksi;
	    $query = "DELETE FROM subkriteria WHERE id_subkriteria=?";
	    $stmt = $koneksi->prepare($query);
	    $stmt->bind_param("s", $id);
	    return $stmt->execute();
	}


	// lainnya
		// ambil data kriteria dari table kriteria
		function ambil_data_kriteria() {
		    global $koneksi;
		    $query = "SELECT * FROM kriteria ORDER BY CAST(SUBSTRING(id_kriteria, 2) AS UNSIGNED)";
		    $result = $koneksi->query($query);

		    $data = array();

		    while ($row = $result->fetch_assoc()) {
		        $data[] = $row;
		    }

		    return $data;
		}
		

	// core (function dieksekusi ketika ada requset)
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		global $koneksi;
		// jika tombol tambah ditekan
		if (isset($_POST['tambah'])) {
			$id_subkriteria = mysqli_real_escape_string($koneksi, $_POST["id_subkriteria"]);
			$id_kriteria = mysqli_real_escape_string($koneksi, $_POST["id_kriteria"]);
	        $sub_kriteria = mysqli_real_escape_string($koneksi, $_POST["sub_kriteria"]);
	        $nilai = mysqli_real_escape_string($koneksi, $_POST["nilai"]);

	        if (tambah_data($id_subkriteria, $id_kriteria, $sub_kriteria, $nilai)) {
	        	$_SESSION['pesan'] = 'Data berhasil ditambah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal menambah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Sub Kriteria');
		}


		// jika tombol ubah ditekan
		if (isset($_POST['ubah'])) {
			$id_subkriteria = mysqli_real_escape_string($koneksi, $_POST["id_subkriteria"]);
			$id_kriteria = mysqli_real_escape_string($koneksi, $_POST["id_kriteria"]);
	        $sub_kriteria = mysqli_real_escape_string($koneksi, $_POST["sub_kriteria"]);
	        $nilai = mysqli_real_escape_string($koneksi, $_POST["nilai"]);

	        if (ubah_data($id_subkriteria, $id_kriteria, $sub_kriteria, $nilai)) {
	        	$_SESSION['pesan'] = 'Data berhasil diubah!';
	        	$_SESSION['status'] = 'success';
	        } else {
	        	$_SESSION['pesan'] = 'Gagal mengubah data!';
	        	$_SESSION['status'] = 'danger';
	        } header('Location: data.php?page=Sub Kriteria');
		}


		// jika tombol hapus ditekan
		if (isset($_POST['hapus'])) {
			$id_subkriteria = mysqli_real_escape_string($koneksi, $_POST["id_subkriteria"]);

			if (hapus_data($id_subkriteria)) {
				$_SESSION['pesan'] = 'Data berhasil dihapus!';
				$_SESSION['status'] = 'success';
			} else {
				$_SESSION['pesan'] = 'Gagal menghapus data!';
				$_SESSION['status'] = 'danger';
			} header('Location: data.php?page=Sub Kriteria');
		}
	}
?>
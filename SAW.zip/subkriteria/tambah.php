<?php $maxID = kode_otomatis(); ?>
<form method="post" role="form" class="input-data">
	<div class="form-group">
		<label class="mb-1">ID Sub Kriteria:</label>
		<input type="text" class="form-control" name="id_subkriteria" value="<?= $maxID; ?>" readonly>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">ID Kriteria:</label>
		<select class="form-control" name="id_kriteria" required>
			<option value="" disabled selected>Pilih ID Kriteria...</option>
			<?php
				$data = ambil_data_kriteria();
				foreach ($data as $row) { ?>
					<option value="<?= $row['id_kriteria']; ?>"><?= $row['id_kriteria']; ?> (<?= $row['nama_kriteria']; ?>)</option>
		    <?php } ?>
		</select>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Sub Kriteria:</label>
		<input type="text" class="form-control" name="sub_kriteria" placeholder="Sub Kriteria" required>
	</div>
	<div class="form-group mt-3">
		<label class="mb-1">Nilai:</label>
		<input type="number" class="form-control" name="nilai" placeholder="Nilai Sub Kriteria" required>
	</div>
	<button type="submit" class="btn btn-ar24f mt-3" name="tambah">Tambah</button>
	<a class="btn mt-3 ms-3" href="data.php?page=Sub Kriteria">kembali</a>
</form>
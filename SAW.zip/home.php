<?php
	session_start();

	// periksa apakah user sudah login
	if (!isset($_SESSION["username"])) {
		header("Location: index.php");
		exit;
	}

	include 'koneksi.php';
	include 'proses.php';

	$data1 = ambil_data_kriteria();
	$data2 = ambil_data_alternatif();
	$data4 = ambil_data_hasil();

	$data_alternatif = array();
	$data_nilaimaxmin = array();
	$data_kriteria = array();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Ar24F | SAW Method</title>
	<meta name="description" content="Simple Additive Weighting Method (SAW Method)">
	<meta name="keywords" content="SAW, SPK, Ar24F">

	<!-- icon -->
	<link rel="icon" href="assets/images/ar24f.png" sizes="any">
	<link rel="apple-touch-icon" href="assets/images/ar24f.png">

	<!-- bootstrap css -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- font icon -->
	<link rel="stylesheet" href="assets/bootstrap-icons/bootstrap-icons.css">

	<!-- main css -->
	<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

	<header id="header" class="header d-flex align-items-center">
		<div class="container d-flex align-items-center justify-content-between">
			<a href="#" class="logo">A<span>r2</span>4F</a>
			<nav id="navbar" class="navbar">
				<ul>
					<li><a class="active" href="#">Home</a></li>
		          	<li class="dropdown"><a href="#"><span>Data Kriteria</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
			            <ul>
			              <li><a href="data.php?page=Data Kriteria">Kriteria</a></li>
			              <li><a href="data.php?page=Sub Kriteria">Sub Kriteria</a></li>
			            </ul>
		          	</li>
					<li><a href="data.php?page=Data Alternatif">Data Alternatif</a></li>
					<li><a class="btn btn-contact" href="https://wa.me/qr/4JPBYRWHBO7BC1" target="_blank">Ingin Konsultasi?</a></li>
				</ul>
			</nav>
			<i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
			<i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
		</div>
	</header>

	<main id="main">
		<section id="process" class="process">
			<div class="container">
				<div class="section-header">
					<h2>Simple Additive Weighting (SAW)</h2>
				</div>

				<form action="" method="post" role="form">
					<div class="table-responsive">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th scope="col" class="nomor">No</th>
									<th scope="col">ID Alternatif</th>
									<th scope="col">Nama Alternatif</th>

									<?php $nomor1 = 1;
										if ($data1) {
											foreach ($data1 as $row) { ?>

												<th scope="col"><?= $row['id_kriteria']; ?> (<?= $row['cost_benefit']; ?>)</th>

									<?php $nomor1++; } } ?>

								</tr>
							</thead>
							<tbody>

								<?php $nomor2 = 1;
									if (empty($data2)) { ?>

										<tr>
											<td colspan="<?= $nomor1 + 3; ?>" class="text-center">Data Alternatif Kosong</td>
										</tr>

								<?php } else { foreach ($data2 as $row1) { ?>

									<tr>
										<th scope="row" class="nomor"><?= $nomor2; ?></th>
										<td><?= $row1['id_alternatif']; ?></td>
										<td><?= $row1['nama_alternatif']; ?></td>

										<?php 
											$data_alternatif[] = array(
											    "id_alternatif" => $row1['id_alternatif'],
											    "nama_alternatif" => $row1['nama_alternatif']
											);
											
											foreach ($data1 as $row2) {
												$kriteria = $row1[$row2['id_kriteria']];
												$data_alternatif[$nomor2 - 1][$row2['id_kriteria']] = $kriteria; ?>

											<td><?= $kriteria; ?></td>

										<?php }  ?>

									</tr>

								<?php $nomor2++; } } ?>

								<tr>
									<th colspan="3" class="minmax">Cost(MIN) atau Benefit(MAX)</th>

									<?php foreach ($data1 as $row1) {
										$id_kriteria = $row1['id_kriteria'];
									 	if ($row1['cost_benefit'] == 'Benefit') {
									 		$nilaimaxmin = PHP_INT_MIN;
									 	} elseif ($row1['cost_benefit'] == 'Cost') {
									 		$nilaimaxmin = PHP_INT_MAX;
									 	}
										foreach ($data2 as $row2) {
											$nilaikriteria = $row2[$row1['id_kriteria']];
											$data3 = ambil_nilai_dari_sub_kriteria($nilaikriteria);
											if ($data3) { $nilaikriteria = $data3['nilai']; }
											$nilaikriteria = hapus_string($nilaikriteria);
											if ($row1['cost_benefit'] == 'Benefit') {
												$nilaimaxmin = max($nilaikriteria, $nilaimaxmin);
											} elseif ($row1['cost_benefit'] == 'Cost') {
												$nilaimaxmin = min($nilaikriteria, $nilaimaxmin);
											}
										}
										$data_nilaimaxmin[$id_kriteria] = $nilaimaxmin;
									?>

										<th class="minmax"><?= $nilaimaxmin; ?></th>

									<?php } ?>

								</tr>
							</tbody>
						</table>
					</div>
					<button type="submit" class="btn btn-ar24f" name="proses">PROSES SAW</button>
				</form>

				<?php if ($showProses) { ?>
				
				<div class="accordion accordion-flush mt-5" id="processlist">
					<div class="accordion-item">
						<h3 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#process-content-1">
								<span class="num">1.</span>Tentukan kriteria (Ci) yang akan digunakan dan beri nilai bobot pada masing-masing kriteria (W).
							</button>
						</h3>
						<div id="process-content-1" class="accordion-collapse collapse" data-bs-parent="#processlist">
							<div class="accordion-body">
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th scope="col" class="nomor">No</th>
												<th scope="col">ID Kriteria</th>
												<th scope="col">Nama Kriteria</th>
												<th scope="col">Bobot</th>
												<th scope="col">Bobot (∑wi = 1)</th>
												<th scope="col">Cost/Benefit</th>
											</tr>
										</thead>
										<tbody>

											<?php $nomor3 = 1;
												if (empty($data1)) { ?>

													<tr><td colspan="6" class="text-center">Data Kriteria Kosong</td></tr>

											<?php } else {
												$totalnilaibobot = 0;
												foreach ($data1 as $row) {
													$totalnilaibobot = $totalnilaibobot + $row['bobot'];
												}
												foreach ($data1 as $row) {
													$sigma_kriteria = $row['bobot']/$totalnilaibobot;
													$data_kriteria[] = array(
													    "id_kriteria" => $row['id_kriteria'],
													    "nama_kriteria" => $row['nama_kriteria'],
													    "bobot" => $row['bobot'],
													    "sigma_kriteria" => $sigma_kriteria,
													    "cost_benefit" => $row['cost_benefit']
													);
											?>

												<tr>
													<th scope="row" class="nomor"><?= $nomor3; ?></th>
													<td><?= $row['id_kriteria']; ?></td>
													<td><?= $row['nama_kriteria']; ?></td>
													<td><?= $row['bobot']; ?></td>
													<td><?= number_format($sigma_kriteria,3); ?></td>
													<td><?= $row['cost_benefit']; ?></td>
												</tr>

											<?php $nomor3++; } } ?>

										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="accordion-item">
						<h3 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#process-content-2">
								<span class="num">2.</span>Menentukan matriks keputusan berdasarkan kriteria (x).
							</button>
						</h3>
						<div id="process-content-2" class="accordion-collapse collapse" data-bs-parent="#processlist">
							<div class="accordion-body">
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th scope="col" class="nomor">No</th>
												<th scope="col">ID Alternatif</th>
												<th scope="col">Nama Alternatif</th>

												<?php $nomor4 = 1;
													if ($data1) {
														foreach ($data1 as $row) { ?>

															<th scope="col"><?= $row['id_kriteria']; ?> (<?= $row['cost_benefit']; ?>)</th>

												<?php $nomor4++; } } ?>

											</tr>
										</thead>
										<tbody>

											<?php $nomor5 = 1;
												if (empty($data_alternatif)) { ?>

													<tr>
														<td colspan="<?= $nomor4 + 3; ?>" class="text-center">Data Alternatif Kosong</td>
													</tr>

											<?php } else { foreach ($data_alternatif as $row1) { ?>

												<tr>
													<th scope="row" class="nomor"><?= $nomor5; ?></th>
													<td><?= $row1['id_alternatif']; ?></td>
													<td><?= $row1['nama_alternatif']; ?></td>

													<?php foreach ($data_kriteria as $row2) {
														$nilaikriteria = $row1[$row2['id_kriteria']];
														$data3 = ambil_nilai_dari_sub_kriteria($nilaikriteria);
														if ($data3) { $nilaikriteria = $data3['nilai']; }
														$nilaikriteria = hapus_string($nilaikriteria);
														$nilaimaxmin = $data_nilaimaxmin[$row2['id_kriteria']];
														if ($row2['cost_benefit'] == 'Benefit') {
															$normalisasi = ($nilaikriteria/$nilaimaxmin);
														} elseif ($row2['cost_benefit'] == 'Cost') {
															$normalisasi = ($nilaimaxmin/$nilaikriteria);
														}
														$data_alternatif[$nomor5-1][$row2['id_kriteria']] = $normalisasi; ?>

														<td><?= number_format($normalisasi,3); ?></td>

													<?php }  ?>

												</tr>

											<?php $nomor5++; } } ?>

										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="accordion-item">
						<h3 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#process-content-3">
								<span class="num">3.</span>Mengalikan matriks ternormalisasi (R) dengan nilai bobot (W) dan menghitung nilai preferensi (Vi) tiap alternatif.
							</button>
						</h3>
						<div id="process-content-3" class="accordion-collapse collapse" data-bs-parent="#processlist">
							<div class="accordion-body">
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th scope="col" class="nomor">No</th>
												<th scope="col">ID Alternatif</th>
												<th scope="col">Nama Alternatif</th>

												<?php $nomor6 = 1;
													if ($data1) {
														foreach ($data1 as $row) { ?>

															<th scope="col"><?= $row['id_kriteria']; ?> (<?= $row['cost_benefit']; ?>)</th>

												<?php $nomor6++; } } ?>

												<th scope="col">Preferensi (Vi)</th>
											</tr>
										</thead>
										<tbody>
											<?php $nomor7 = 1;
												if (empty($data_alternatif)) { ?>

													<tr>
														<td colspan="<?= $nomor6 + 4; ?>" class="text-center">Data Alternatif Kosong</td>
													</tr>

											<?php } else { foreach ($data_alternatif as $row1) { ?>

												<tr>
													<th scope="row" class="nomor"><?= $nomor7; ?></th>
													<td><?= $row1['id_alternatif']; ?></td>
													<td><?= $row1['nama_alternatif']; ?></td>

													<?php $totalpreferensi = 0;
														foreach ($data_kriteria as $row2) {
														$preferensi = $row1[$row2['id_kriteria']]*$row2['sigma_kriteria'];
														$totalpreferensi = $totalpreferensi + $preferensi;
													?>

														<td><?= number_format($preferensi,3); ?></td>

													<?php } ubah_data_hasil($row1['id_alternatif'], $totalpreferensi); ?>

													<td><?= number_format($totalpreferensi,3); ?></td>
												</tr>

											<?php $nomor7++; } } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="accordion-item">
						<h3 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#process-content-4">
								<span class="num">4.</span>Perankingan.
							</button>
						</h3>
						<div id="process-content-4" class="accordion-collapse collapse" data-bs-parent="#processlist">
							<div class="accordion-body">
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th scope="col">Ranking</th>
												<th scope="col">ID Alternatif</th>
												<th scope="col">Nama Alternatif</th>
												<th scope="col">Preferensi (Vi)</th>
											</tr>
										</thead>
										<tbody>

											<?php $nomor8 = 1;
												if (empty($data4)) { ?>

													<tr>
														<td colspan="4" class="text-center">Data Hasil Kosong</td>
													</tr>

											<?php } else { foreach ($data4 as $row) { ?>

												<tr>
													<th scope="row"><?= $nomor8; ?></th>
													<td><?= $row['id_alternatif']; ?></td>
													<td><?= $row['nama_alternatif']; ?></td>
													<td><?= number_format($row['hasil'],3); ?></td>
												</tr>

											<?php $nomor8++; } } ?>

										</tbody>
									</table>
								</div>
								<a class="btn btn-ar24f" href="laporan.php" target="_blank">CETAK HASIL</a>
							</div>
						</div>
					</div>
				</div>

				<?php } ?>
				
			</div>
		</section>
	</main>

	<footer id="footer" class="footer">
		<div class="container">
			<div class="footer-info">
				<h4>Simple Additive Weighting (SAW)</h4>
				<p>
					Simple Additive Weighting (SAW) merupakan sebuah algoritma yang dapat memprediksi sebuah keputusan yang akan diambil dengan menjumlahkan bobot sesuai dengan kriteria yang telah ditentukan dan juga membutuhkan proses normalisasi matriks keputusan (X) ke suatu skala yang dapat diperbandingkan dengan semua rating alternatif yang ada
					(<a href="https://www.unisbank.ac.id/ojs/index.php/fti1/article/view/364/241">Eniyati, 2011</a>).
				</p>
			</div>
		</div>
		<div class="container mt-5">
			<div class="copyright">
				&copy; Copyright <strong><span>Simple Additive Weighting (SAW)</span></strong>. All Rights Reserved
      		</div>
      		<div class="credits">
      			Made by <a href="#">Rizky Fadhillah</a>
      		</div>
    	</div>
	</footer>

	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<!-- main js -->
	<script src="assets/js/main.js"></script>
</body>
</html>
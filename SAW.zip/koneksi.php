<?php
    // konfigurasi database
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "saw";

    // membuat koneksi ke database
    $koneksi = new mysqli($host, $username, $password, $database);

    // memeriksa koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }
?>
<?php
	// login
	function login($username, $password) {
        global $koneksi;
        $query = "SELECT * FROM login WHERE username = '$username'";
        $result = $koneksi->query($query);

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if ($password === $user['password']) {
                return $user;
            }
        }
        return false;
    }


    // hilangkan string
    function hapus_string($isi) {
        $pattern = '/[^0-9,]/';
        $replacement = '';
        $isi = preg_replace($pattern, $replacement, $isi);
        $isi = str_replace('.', '', $isi);
        $isi = str_replace(',', '.', $isi);

        return $isi;
    }


    // ambil data kriteria dari table kriteria
    function ambil_data_kriteria() {
        global $koneksi;
        $query = "SELECT * FROM kriteria ORDER BY CAST(SUBSTRING(id_kriteria, 2) AS UNSIGNED)";
        $result = $koneksi->query($query);

        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }


    // ambil data alternatif dari table alternatif
    function ambil_data_alternatif() {
        global $koneksi;
        $query = "SELECT * FROM alternatif ORDER BY CAST(SUBSTRING(id_alternatif, 3) AS UNSIGNED)";
        $result = $koneksi->query($query);

        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }


    // ambil data nilai dari table sub kriteria berdasarkan id
    function ambil_nilai_dari_sub_kriteria($value1) {
        global $koneksi;
        $query = "SELECT * FROM subkriteria WHERE sub_kriteria = ?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("s", $value1);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        }
    }


    // masukkan hasil proses ke dalam tabel hasil
    function ubah_data_hasil($id, $value1) {
        global $koneksi;
        $query = "UPDATE hasil SET hasil=? WHERE id_alternatif=?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("ss", $value1, $id);
        return $stmt->execute();
    }


    // ambil data hasil dari table hasil
    function ambil_data_hasil() {
        global $koneksi;
        $query = "SELECT * FROM hasil ORDER BY hasil desc";
        $result = $koneksi->query($query);

        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }


    // core (function dieksekusi ketika ada requset)
    $showProses = false;
    $errorlogin = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // jika tombol proses ditekan
        if (isset($_POST['proses'])) {
            $showProses = !$showProses;
        }

        // jika tombol login ditekan
        if (isset($_POST['login'])) {
            $username = mysqli_real_escape_string($koneksi, $_POST["username"]);
            $password = mysqli_real_escape_string($koneksi, $_POST["password"]);

            $user = login($username, $password);

            if ($user) {
                $_SESSION["username"] = $user["username"];
                header("Location: home.php");
                exit;
            } else {
                $errorlogin = 'Username atau Password anda salah!';
            }
        }
    }
?>
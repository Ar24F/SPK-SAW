-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Sep 2023 pada 14.57
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saw`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` varchar(10) NOT NULL,
  `nama_alternatif` text NOT NULL,
  `C1` varchar(50) DEFAULT NULL,
  `C2` varchar(50) DEFAULT NULL,
  `C3` varchar(50) DEFAULT NULL,
  `C4` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`, `C1`, `C2`, `C3`, `C4`) VALUES
('AL1', 'Mahasiswa1', '3,45', 'Rp1.245.000', '3 - 4 Prestasi', '2 Anak'),
('AL10', 'Mahasiswa10', '3,94', 'Rp620.000', 'Tidak Ada', '> 6 Anak'),
('AL2', 'Mahasiswa2', '2,98', 'Rp1.200.000', '1 - 2 Prestasi', '3 Anak'),
('AL3', 'Mahasiswa3', '3,72', 'Rp2.150.000', 'Tidak Ada', '2 Anak'),
('AL4', 'Mahasiswa4', '3,10', 'Rp1.650.000', '1 - 2 Prestasi', '> 6 Anak'),
('AL5', 'Mahasiswa5', '3,88', 'Rp550.000', '> 5 Prestasi', '4 Anak'),
('AL6', 'Mahasiswa6', '2,67', 'Rp850.000', '1 - 2 Prestasi', '1 Anak'),
('AL7', 'Mahasiswa7', '3,56', 'Rp3.680.000', 'Tidak Ada', '3 Anak'),
('AL8', 'Mahasiswa8', '3,25', 'Rp2.750.000', '1 - 2 Prestasi', '1 Anak'),
('AL9', 'Mahasiswa9', '2,89', 'Rp1.450.000', '4 - 5 Prestasi', '2 Anak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hasil`
--

CREATE TABLE `hasil` (
  `id_alternatif` varchar(10) NOT NULL,
  `nama_alternatif` text NOT NULL,
  `hasil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `hasil`
--

INSERT INTO `hasil` (`id_alternatif`, `nama_alternatif`, `hasil`) VALUES
('AL1', 'Mahasiswa1', '0.45327470716422'),
('AL10', 'Mahasiswa10', '0.74728667547004'),
('AL2', 'Mahasiswa2', '0.45709299334066'),
('AL3', 'Mahasiswa3', '0.41343913174245'),
('AL4', 'Mahasiswa4', '0.5467826362296'),
('AL5', 'Mahasiswa5', '0.71697291734695'),
('AL6', 'Mahasiswa6', '0.4086485331806'),
('AL7', 'Mahasiswa7', '0.41206297380446'),
('AL8', 'Mahasiswa8', '0.33232305241389'),
('AL9', 'Mahasiswa9', '0.40201025737614');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` varchar(10) NOT NULL,
  `nama_kriteria` text NOT NULL,
  `bobot` int(11) NOT NULL,
  `cost_benefit` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `nama_kriteria`, `bobot`, `cost_benefit`) VALUES
('C1', 'Nilai Indeks Prestasi Akademik (IPK)', 80, 'Benefit'),
('C2', 'Penghasilan Orang Tua', 75, 'Cost'),
('C3', 'Prestasi Yang Pernah Diraih', 65, 'Benefit'),
('C4', 'Jumlah Tanggungan Orang Tua', 65, 'Benefit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `subkriteria`
--

CREATE TABLE `subkriteria` (
  `id_subkriteria` varchar(10) NOT NULL,
  `id_kriteria` varchar(10) NOT NULL,
  `sub_kriteria` text NOT NULL,
  `nilai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `subkriteria`
--

INSERT INTO `subkriteria` (`id_subkriteria`, `id_kriteria`, `sub_kriteria`, `nilai`) VALUES
('SC1', 'C3', 'Tidak Ada', 1),
('SC10', 'C4', '5 Anak', 5),
('SC11', 'C4', '> 6 Anak', 6),
('SC2', 'C3', '1 - 2 Prestasi', 2),
('SC3', 'C3', '3 - 4 Prestasi', 3),
('SC4', 'C3', '4 - 5 Prestasi', 4),
('SC5', 'C3', '> 5 Prestasi', 5),
('SC6', 'C4', '1 Anak', 1),
('SC7', 'C4', '2 Anak', 2),
('SC8', 'C4', '3 Anak', 3),
('SC9', 'C4', '4 Anak', 4);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indeks untuk tabel `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indeks untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `subkriteria`
--
ALTER TABLE `subkriteria`
  ADD PRIMARY KEY (`id_subkriteria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
